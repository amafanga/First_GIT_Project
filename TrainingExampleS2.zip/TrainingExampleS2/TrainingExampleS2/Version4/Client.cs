﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version4
{
    public class Client
    {
        public string ClientName { get; set; }
        public string ClientAccountNumber { get; set; }
        public string ClientContactName { get; set; }
        public string ClientContactNumber { get; set; }        
    }
}
