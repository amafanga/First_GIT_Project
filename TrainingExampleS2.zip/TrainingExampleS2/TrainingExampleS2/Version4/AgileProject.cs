﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version4
{
    
    public abstract class AgileProject: Project
    {
        
        protected List<UserStory> _userStories = new List<UserStory>();
        public abstract void AddUserStories(UserStory userStory);
        public UserStory GetUserStory(int index)
        {
            return _userStories[index];
        }        
        public string ScrumMaster { get; set; }
    }
}
