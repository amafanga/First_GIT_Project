﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version4
{
    public class AgileFixedCostProject: AgileProject
    {
        
        public override double GetRemainingValue()
        {
            return GetRemainingBudget();
        }
        public override byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(AgileFixedCostProject));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
        public override void AddUserStories(UserStory userStory)
        {
            _userStories.Add(userStory);
        }
        public override double GetTotalValue()
        {
            return Budget;
        }
    }
}
