﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version4
{    
    public class WaterfallProject: Project
    {           
        public double Progress { get; set; }        
        
        public override Double GetRemainingValue()
        {
            double value = 0f;            
            value = GetRemainingBudget();            
            return value;
        }
        public override Double GetTotalValue()
        {
            return GetRemainingBudget() / Progress * 100;
        }
        public override byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(WaterfallProject));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray(); 
        }
    }    
}
