﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version4
{
    public enum ProjectStatus { Presales, Initiation, Planning, Sprint0, Execution, Stabilization, Deployment, SignedOff };    
    public abstract class Project
    {
        public int Budget { get; set; }
        public string ProjectName { get; set; }
        public Client Client { get; set; }
        public string AccountExecutive { get; set; }
        public string TechLead { get; set; }
        public ProjectStatus ProjectStatus { get; set; }
        public Double Invoiced { get; set; }
        public virtual Double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
        public abstract Double GetRemainingValue();
        public abstract Double GetTotalValue();
        public abstract byte[] GetProjectData();        
    }
}
