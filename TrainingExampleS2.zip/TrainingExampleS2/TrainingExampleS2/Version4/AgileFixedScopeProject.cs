﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version4
{
    public class AgileFixedScopeProject : AgileProject
    {
        public override double GetRemainingValue()
        {
            return GetTotalValue() - Invoiced;
        }
        public override byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(AgileFixedScopeProject));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
        public override void AddUserStories(UserStory userStory)
        {
            if (ProjectStatus == ProjectStatus.Sprint0)
            {
                _userStories.Add(userStory);
            }
        }
        public override double GetTotalValue()
        {
            double progress = GetSizeOfCompletedUserStories() / GetTotalSizeOfUserStories();
            return GetRemainingBudget() / progress * 100;
        }

        private int GetTotalSizeOfUserStories()
        {
            throw new NotImplementedException();
        }

        private int GetSizeOfCompletedUserStories()
        {
            throw new NotImplementedException();
        }
    }
}
