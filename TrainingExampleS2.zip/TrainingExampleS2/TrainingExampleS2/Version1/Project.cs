﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version1
{
    public enum ProjectStatus { Presales, Initiation, Planning, Sprint0, Execution, Stabilization, Deployment, SignedOff };
    public enum ProjectType { WaterfallFixedCost, AgileFixedCost, AgileFixedScope };//Add Agile
    public class Project
    {
        public double Budget { get; set; }
        public string ProjectName { get; set; }
        public string ClientName { get; set; }
        public string ClientAccountNumber { get; set; }
        public string ClientContactName { get; set; }
        public string ClientContactNumber { get; set; }
        public string AccountExecutive { get; set; }
        public string TechLead { get; set; }
        public string ScrumMaster { get; set; }
        private List<UserStory> _userStories = new List<UserStory>();
        public void AddUserStories(UserStory userStory)
        {
            if ((ProjectType == ProjectType.AgileFixedCost) ||
                ((ProjectType == ProjectType.AgileFixedScope) && (ProjectStatus == ProjectStatus.Sprint0)))
            {
                _userStories.Add(userStory);
            }
            else
            {
                //Inidicate that new user stories can't be added
            }
        }
        public UserStory GetUserStory(int index)
        {
            return _userStories[index];
        }
        public ProjectType ProjectType { get; set; }
        public double Progress { get; set; }
        public ProjectStatus ProjectStatus { get; set; }
        public Double Invoiced { get; set; }
        public Double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
        public Double GetRemainingValue()
        {
            double value = 0f;
            switch (ProjectType)
            {
                case Version1.ProjectType.WaterfallFixedCost:
                    {
                        value = GetRemainingBudget();
                        break;
                    }
                case Version1.ProjectType.AgileFixedCost:
                    {
                        value = GetRemainingBudget();
                        break;
                    }
                case Version1.ProjectType.AgileFixedScope:
                    {
                        value = GetTotalValue() - Invoiced;
                        break;
                    }
            }
            return value;
        }
        public Double GetTotalValue()
        {
            return GetRemainingBudget() / Progress * 100;
        }
        public byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(Project));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
    }    
}
