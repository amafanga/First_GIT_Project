﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version2
{
    public enum ProjectStatus { Presales, Initiation, Planning, Sprint0, Execution, Stabilization, Deployment, SignedOff };
    public enum ProjectType { WaterfallFixedCost, AgileFixedCost, AgileFixedScope };//Add Agile
    public class Project
    {
        private string _scrumMaster = string.Empty;
        private const string _scrumMasterErrorText = "A Waterfall Project does not have a scrum master";
        public double Budget { get; set; }
        public string ProjectName { get; set; }
        public Client Client { get; set; }
        public string AccountExecutive { get; set; }
        public string TechLead { get; set; }
        public string ScrumMaster 
        { 
            get 
            { 
                return _scrumMaster; 
            } 
            set
            {
                if (ProjectType != ProjectType.WaterfallFixedCost)
                {
                    _scrumMaster = value;
                }
                else 
                {
                    throw new ArgumentException(_scrumMasterErrorText);                     
                }
            }
        }
        private List<UserStory> _userStories = new List<UserStory>();
        public void AddUserStories(UserStory userStory)
        {
            if ((ProjectType == ProjectType.AgileFixedCost) ||
                ((ProjectType == ProjectType.AgileFixedScope) && (ProjectStatus == ProjectStatus.Sprint0)))
            {
                _userStories.Add(userStory);
            }
            else
            {
                //Inidicate that new user stories can't be added
            }
        }
        public UserStory GetUserStory(int index)
        {
            return _userStories[index];
        }
        public ProjectType ProjectType { get; set; }
        public double Progress { get; set; }
        public ProjectStatus ProjectStatus { get; set; }
        public Double Invoiced { get; set; }
        public Double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
        public Double GetRemainingValue()
        {
            double value = 0f;
            switch (ProjectType)
            {
                case Version2.ProjectType.WaterfallFixedCost:
                    {
                        value = GetRemainingBudget();
                        break;
                    }
                case Version2.ProjectType.AgileFixedCost:
                    {
                        value = GetRemainingBudget();
                        break;
                    }
                case Version2.ProjectType.AgileFixedScope:
                    {
                        value = GetTotalValue() - Invoiced;
                        break;
                    }
            }
            return value;
        }
        public Double GetTotalValue()
        {
            double value = 0F;
            switch (ProjectType)
            {
                case Version2.ProjectType.WaterfallFixedCost:
                    {
                        value =  Budget;
                        break;
                    }
                case Version2.ProjectType.AgileFixedCost:
                    {
                        value = Budget;
                        break;
                    }
                case Version2.ProjectType.AgileFixedScope:
                    {
                        value = GetRemainingBudget() / Progress * 100;
                        break;
                    }
            }
            return value;
        }
        public byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(Project));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
    }    
}
