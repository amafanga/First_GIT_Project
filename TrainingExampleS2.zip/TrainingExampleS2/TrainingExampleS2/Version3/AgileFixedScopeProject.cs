﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version3
{
    public class AgileFixedScopeProject : AgileFixedCostProject
    {
        public override double GetRemainingValue()
        {
            return GetTotalValue() - Invoiced;
        }
        public override void AddUserStories(UserStory userStory)
        {
            if (ProjectStatus == Version3.ProjectStatus.Sprint0)
            {
                base.AddUserStories(userStory); 
            }
        }
        public override byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(AgileFixedScopeProject));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
    }
}
