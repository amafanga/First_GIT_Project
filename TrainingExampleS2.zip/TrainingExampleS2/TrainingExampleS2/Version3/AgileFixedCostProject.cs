﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version3
{
    public class AgileFixedCostProject: WaterfallProject
    {
        private List<UserStory> _userStories = new List<UserStory>();
        public virtual void AddUserStories(UserStory userStory)
        {
            _userStories.Add(userStory);            
        }
        public  UserStory GetUserStory(int index)
        {
            return _userStories[index];
        }
        private string _scrumMaster = string.Empty;
        public string ScrumMaster { get; set; }
        public override double GetRemainingValue()
        {
            return GetRemainingBudget();
        }
    }
}
