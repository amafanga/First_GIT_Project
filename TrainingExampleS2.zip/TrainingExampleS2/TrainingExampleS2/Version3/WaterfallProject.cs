﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version3
{
    public enum ProjectStatus { Presales, Initiation, Planning, Sprint0, Execution, Stabilization, Deployment, SignedOff };
    
    public class WaterfallProject
    {     
        public int Budget { get; set; }
        public string ProjectName { get; set; }
        public Client Client { get; set; }
        public string AccountExecutive { get; set; }
        public string TechLead { get; set; }
        public double Progress { get; set; }
        public ProjectStatus ProjectStatus { get; set; }
        public Double Invoiced { get; set; }
        public Double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
        public virtual Double GetRemainingValue()
        {
            double value = 0f;            
            value = GetRemainingBudget();            
            return value;
        }
        public Double GetTotalValue()
        {
            return GetRemainingBudget() / Progress * 100;
        }
        public virtual byte[] GetProjectData()
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(WaterfallProject));
                serializer.WriteObject(ms, this);
                ms.Position = 0;
            }
            return ms.ToArray();
        }
    }    
}
