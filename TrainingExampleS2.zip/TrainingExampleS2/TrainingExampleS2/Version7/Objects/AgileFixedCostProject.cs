﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7.Objects
{
    public class AgileFixedCostProject: AgileProject
    {        
        public override double GetRemainingValue()
        {
            return GetRemainingBudget();
        }
        public override string GetProjectStatusReport()
        {
            return string.Empty;
        }
        public override void AddUserStories(IUserStory userStorie)
        {
            _userStories.Add(userStorie);
        }
        public override double GetTotalValue()
        {
            return Budget;
        }
        public override double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
    }
}
