﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7.Objects
{
    public enum ProjectType { WaterfallFixedCost, AgileFixedCost, AgileFixedScope };
    public class ProjectFactory<T, S> 
        where T: IProject, new()
        where S: ProjectSerializer<T>, new()
    {
        public T GetProjectObject()
        {
            T result = new T();                        
            return result;
        }
        public S GetProjectSerializer()
        {
            return new S();
        }
    }
}
