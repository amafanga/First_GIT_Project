﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7.Objects
{

    public class ProjectSerializer<T> : IProjectSerializer where T : IProject, new()
    {
        public byte[] GetProjectData(T project)
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(T));
                serializer.WriteObject(ms, project);
                ms.Position = 0;
            }
            return ms.ToArray(); ;
        }
        public byte[] GetProjectData(IProject project)
        {
            return GetProjectData((T)project);
        }
    }    
    
}
