﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7.Objects
{
    public class Client : IClient
    {
        public string ClientName { get; set; }
        public string ClientAccountNumber { get; set; }
        public string ClientContactName { get; set; }
        public string ClientContactNumber { get; set; }        
    }
}
