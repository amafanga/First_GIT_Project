﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7.Objects
{

    public abstract class AgileProject : Project, IAgileProject
    {
        protected List<IUserStory> _userStories = new List<IUserStory>();
        public AgileProjectStatus ProjectStatus { get; set; }        
        public abstract void AddUserStories(IUserStory userStory);
        public IUserStory GetUserStory(int index)
        {
            return _userStories[index];
        }        
        public string ScrumMaster { get; set; }
    }
}
