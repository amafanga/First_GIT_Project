﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version7.Interfaces
{
    public interface IProject
    {
        int Budget { get; set; }
        string ProjectName { get; set; }
        IClient Client { get; set; }
        string AccountExecutive { get; set; }
        string TechLead { get; set; }

        Double Invoiced { get; set; }
        Double GetRemainingBudget();
        Double GetRemainingValue();
        Double GetTotalValue();
        string GetProjectStatusReport();
    }
}
