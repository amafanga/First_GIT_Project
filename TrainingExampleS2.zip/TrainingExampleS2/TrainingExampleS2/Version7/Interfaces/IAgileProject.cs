﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version7.Interfaces
{
    public enum AgileProjectStatus { Presales, Initiation, Sprint0, Sprintn, Stabilization, Deployment, SignedOff };
    public interface IAgileProject: IProject
    {
        AgileProjectStatus ProjectStatus { get; set; }
        void AddUserStories(IUserStory userStory);
        IUserStory GetUserStory(int index);
        string ScrumMaster { get; set; }
    }
}
