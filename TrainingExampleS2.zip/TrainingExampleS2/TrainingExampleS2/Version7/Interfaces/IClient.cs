﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version7.Interfaces
{
    public interface IClient
    {
        string ClientName { get; set; }
        string ClientAccountNumber { get; set; }
        string ClientContactName { get; set; }
        string ClientContactNumber { get; set; }  
    }
}
