﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainingExampleS2.Version7.Objects;
using TrainingExampleS2.Version7.Interfaces;

namespace TrainingExampleS2.Version7
{
    class Test
    {
        ProjectFactory<AgileFixedCostProject, ProjectSerializer<AgileFixedCostProject>> projectFactory = new ProjectFactory<AgileFixedCostProject, ProjectSerializer<AgileFixedCostProject>>();
        void doStuff()
        {
            AgileFixedCostProject project = projectFactory.GetProjectObject();
            IProjectSerializer serializer = projectFactory.GetProjectSerializer();
        }

    }
}
