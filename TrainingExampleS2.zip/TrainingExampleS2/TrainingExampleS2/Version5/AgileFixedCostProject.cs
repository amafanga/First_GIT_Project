﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version5
{
    public class AgileFixedCostProject: AgileProject
    {        
        public override double GetRemainingValue()
        {
            return GetRemainingBudget();
        }
        public override string GetProjectStatusReport()
        {
            return string.Empty;
        }
        public override void AddUserStories(UserStory userStory)
        {
            _userStories.Add(userStory);
        }
        public override double GetTotalValue()
        {
            return Budget;
        }
        public override double GetRemainingBudget()
        {
            return Budget - Invoiced;
        }
    }
}
