﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version5
{
    public class AgileFixedScopeProjectSerializer
    {
        public byte[] GetProjectData(AgileFixedScopeProject project)
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(AgileFixedCostProject));
                serializer.WriteObject(ms, project);
                ms.Position = 0;
            }
            return ms.ToArray(); ;
        }
    }
}
