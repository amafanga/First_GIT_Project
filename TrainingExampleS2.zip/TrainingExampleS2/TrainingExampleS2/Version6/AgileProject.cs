﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public enum AgileProjectStatus { Presales, Initiation, Sprint0, Sprintn, Stabilization, Deployment, SignedOff };
    public abstract class AgileProject: Project
    {
        public AgileProjectStatus ProjectStatus { get; set; }
        protected List<UserStory> _userStories = new List<UserStory>();
        public abstract void AddUserStories(UserStory userStorie);
        public UserStory GetUserStory(int index)
        {
            return _userStories[index];
        }        
        public string ScrumMaster { get; set; }
    }
}
