﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public enum WaterfallProjectStatus { Presales, Initiation, Planning, Execution, Stabilization, Deployment, SignedOff };
    public class WaterfallProject: Project
    {
        public WaterfallProjectStatus ProjectStatus { get; set; }
        
        public double Progress { get; set; }        
        
        public override Double GetRemainingValue()
        {
            double value = 0f;            
            value = GetRemainingBudget();            
            return value;
        }
        public override Double GetTotalValue()
        {
            return GetRemainingBudget() / Progress * 100;
        }
        public override string GetProjectStatusReport()
        {
            return String.Empty;
            // You could use a string builder to build up a text report that represents the current project status.
        }
        public override double GetRemainingBudget()
        {
            return Budget - Invoiced;            
        }
    }    
}
