﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace TrainingExampleS2.Version6
{

    public class ProjectSerializer<T> : IProjectSerializer where T : Project, new()
    {
        public byte[] GetProjectData(T project)
        {
            MemoryStream ms = new MemoryStream();
            using (ms)
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(T));
                serializer.WriteObject(ms, project);
                ms.Position = 0;
            }
            return ms.ToArray(); ;
        }
        public byte[] GetProjectData(Project project)
        {
            return GetProjectData(project as T);
        }
    }    
    
}
