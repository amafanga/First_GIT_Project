﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public enum UserStoryStatus { Open, Active, Resolved, Closed }
    public class UserStory
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Notes { get; set; }
        public UserStoryStatus UserStoryStatus { get; set; }
        public int? Spring { get; set; }
    }
}
