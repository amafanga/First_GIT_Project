﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public class ProjectSerializerFactory
    {
        public IProjectSerializer GetProjectSerializer(ProjectType projectType)
        {
            IProjectSerializer result = null;
            switch (projectType)
            {
                case ProjectType.WaterfallFixedCost:
                    {
                        result = new ProjectSerializer<WaterfallProject>();
                        break;
                    }
                case ProjectType.AgileFixedCost:
                    {
                        result = new ProjectSerializer<AgileFixedCostProject>();
                        break;
                    }
                case ProjectType.AgileFixedScope:
                    {
                        result = new ProjectSerializer<AgileFixedScopeProject>();                        
                        break;
                    }
            }
            return result;
        }
    }
}
