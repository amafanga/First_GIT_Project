﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public interface IProjectSerializer
    {
        byte[] GetProjectData(Project project);
    }
}
