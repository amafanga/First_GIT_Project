﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public class AgileFixedScopeProject : AgileProject
    {
        public override double GetRemainingValue()
        {
            return GetTotalValue() - Invoiced;
        }
        public override string GetProjectStatusReport()
        {
            return String.Empty;
            // You could use a string builder to build up a text report that represents the current project status.
        }
        public override void AddUserStories(UserStory userStorie)
        {
            if (ProjectStatus == AgileProjectStatus.Sprint0)
            {
                _userStories.Add(userStorie);
            }
        }
        public override double GetTotalValue()
        {
            double progress = GetSizeOfCompletedUserStories() / GetTotalSizeOfUserStories();
            return GetRemainingBudget() / progress * 100;
        }
        public override double GetRemainingBudget()
        {
            return GetTotalValue() - Invoiced;                    
        }
        private int GetTotalSizeOfUserStories()
        {
            throw new NotImplementedException();
        }
        private int GetSizeOfCompletedUserStories()
        {
            throw new NotImplementedException();
        }
    }
}
