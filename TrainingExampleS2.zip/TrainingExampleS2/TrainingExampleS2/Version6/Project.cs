﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainingExampleS2.Version6
{
    public abstract class Project
    {
        public int Budget { get; set; }
        public string ProjectName { get; set; }
        public Client Client { get; set; }
        public string AccountExecutive { get; set; }
        public string TechLead { get; set; }
        
        public Double Invoiced { get; set; }
        public abstract Double GetRemainingBudget();
        public abstract Double GetRemainingValue();
        public abstract Double GetTotalValue();
        public abstract string GetProjectStatusReport();
    }
}
